Paypal Integration Readme

Paypal is one of the top online payment system providing an option to people for transfering money through internet. And all of the eCommerce stores today integrate the Paypal payment method in order to make online transaction. Though, to integrate this, there is a number of tasks that needs to be done. 

And here, I’ve created the same demo on [How to Set Up Paypal Payment Gateway Integration in PHP](https://www.spaceotechnologies.com/paypal-payment-gateway-integration-php/). 

If you face any issue implementing it, you can contact me for help. Also, if you want to implement this feature in your online store and looking to [Hire PHP developer](http://www.spaceotechnologies.com/hire-php-developer/) to help you, then you can contact Space-O Technologies for the same.
